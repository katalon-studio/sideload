<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Tap Views Item - Cucumber Runner</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>5</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>3f2daa10-826e-4527-98dc-6dbd0126dfed</testSuiteGuid>
   <testCaseLink>
      <guid>8394e803-e08b-4672-baee-007fa3c23d9e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Tap Views Item - Cucumber Runner</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
