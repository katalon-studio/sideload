$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/thongnmtran/Desktop/workspace/sideload/CucumberDemoProject/Include/features/Tap Views Item.feature");
formatter.feature({
  "name": "Tap",
  "description": "  I want to tap Views item",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "name": "Tap Views Item",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "The application load successfully",
  "keyword": "Given "
});
formatter.step({
  "name": "I tap the Views item",
  "keyword": "When "
});
formatter.step({
  "name": "I capture a screenshot",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "name",
        "value",
        "status"
      ]
    },
    {
      "cells": [
        "name1",
        "5",
        "success"
      ]
    }
  ]
});
formatter.scenario({
  "name": "Tap Views Item",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "The application load successfully",
  "keyword": "Given "
});
formatter.match({
  "location": "StartMobileApp.startApplication()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I tap the Views item",
  "keyword": "When "
});
formatter.match({
  "location": "StartMobileApp.tapViewsItem()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I capture a screenshot",
  "keyword": "Then "
});
formatter.match({
  "location": "StartMobileApp.captureAScreenShot()"
});
formatter.result({
  "status": "passed"
});
});